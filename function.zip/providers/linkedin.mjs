/**
 * linkedin.mjs — LinkedIn job provider using Puppeteer Stealth (headless)
 * 
 * Uses puppeteer-extra with stealth plugin to bypass LinkedIn's bot detection.
 * Runs completely in background — no browser window, no user interaction.
 * 
 * Cookie expiration triggers email notification.
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import nodemailer from 'nodemailer';

puppeteer.use(StealthPlugin());

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = join(__dirname, '../config/linkedin.yml');
const EMAIL_CONFIG_PATH = join(__dirname, '../config/email.yml');
const CHROME_PATH = process.env.CHROME_PATH
  || (existsSync('/usr/bin/chromium') ? '/usr/bin/chromium'
  : existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome'
  : existsSync('/ms-playwright/chromium-1228/chrome-linux/chrome') ? '/ms-playwright/chromium-1228/chrome-linux/chrome'
  : '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');

// ─── Cookie loading ────────────────────────────────────────────────────────

async function loadCookies(userId) {
  // Try DB first if userId provided
  if (userId) {
    try {
      const { getUserCookies } = await import('../lib/db-reader.mjs');
      const { decryptCookies } = await import('../lib/cookie-crypto.mjs');
      const row = await getUserCookies(userId, 'linkedin');
      if (row?.encrypted) {
        const cookies = decryptCookies(userId, row.encrypted);
        if (cookies && cookies.length > 0) {
          console.log(`[linkedin] Loaded ${cookies.length} cookies from DB for user ${userId.slice(0, 12)}...`);
          return { cookies, exportedAt: row.exportedAt, source: 'db' };
        }
      }
    } catch (e) {
      console.warn(`[linkedin] DB cookie load failed, falling back to file: ${e.message}`);
    }
  }

  // Fallback to local YAML file
  if (!existsSync(CONFIG_PATH)) return null;
  
  const yaml = readFileSync(CONFIG_PATH, 'utf8');
  const cookies = [];
  
  const cookieRegex = /- name:\s*"([^"]+)"\s*\n\s*value:\s*"([^"]+)"/g;
  let match;
  while ((match = cookieRegex.exec(yaml)) !== null) {
    cookies.push({ name: match[1], value: match[2], domain: '.linkedin.com' });
  }
  
  const exportedMatch = yaml.match(/exportedAt:\s*"([^"]+)"/);
  const exportedAt = exportedMatch?.[1] ? new Date(exportedMatch[1]) : null;
  
  return { cookies, exportedAt, source: 'file' };
}

function checkCookieAge(exportedAt) {
  if (!exportedAt) return { valid: false, days: -1 };
  
  const age = Date.now() - exportedAt.getTime();
  const days = Math.round(age / (24 * 60 * 60 * 1000));
  
  return { valid: days < 30, days };
}

// ─── Expiration email ──────────────────────────────────────────────────────

async function sendExpirationEmail() {
  try {
    if (!existsSync(EMAIL_CONFIG_PATH)) return;
    
    const emailConfig = readFileSync(EMAIL_CONFIG_PATH, 'utf8');
    const userMatch = emailConfig.match(/user:\s*"([^"]+)"/);
    const passMatch = emailConfig.match(/app_password:\s*"([^"]+)"/);
    
    if (!userMatch || !passMatch) return;
    
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: userMatch[1],
        pass: passMatch[1],
      },
    });
    
    await transporter.sendMail({
      from: `"Career-Ops" <${userMatch[1]}>`,
      to: userMatch[1],
      subject: '[Career-Ops] LinkedIn Cookies Expired — Please Re-login',
      html: `
        <h2>LinkedIn Session Expired</h2>
        <p>Your LinkedIn cookies have expired. The system can no longer scrape LinkedIn job listings.</p>
        <p><strong>To fix this:</strong></p>
        <ol>
          <li>Open terminal in the career-ops folder</li>
          <li>Run: <code>node linkedin-auto-save.js</code></li>
          <li>Log in to LinkedIn in the browser window</li>
          <li>Wait for "Cookies saved" message</li>
        </ol>
        <p>This takes about 30 seconds. The system will automatically use the new cookies.</p>
        <hr>
        <p><small>— Career-Ops Automation</small></p>
      `,
    });
    
    console.log('📧 Expiration email sent');
  } catch (err) {
    // Silent fail on email
  }
}

// ─── Headless scraping with Puppeteer Stealth ──────────────────────────────

async function scrapeLinkedInJobs(keywords, maxJobs = 25, userId) {
  const data = await loadCookies(userId);
  
  if (!data || data.cookies.length === 0) {
    console.log('  ⚠️  LinkedIn: No cookies. Run: node linkedin-auto-save.js');
    return [];
  }
  
  const { valid, days } = checkCookieAge(data.exportedAt);
  
  if (!valid) {
    console.log(`  ❌ LinkedIn: Cookies expired (${days}d). Re-login needed.`);
    await sendExpirationEmail();
    return [];
  }
  
  if (days > 25) {
    console.log(`  ⚠️  LinkedIn: Cookies expiring in ${30 - days} days.`);
  }
  
  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: CHROME_PATH,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 800 });
    
    // Inject saved cookies
    await page.setCookie(...data.cookies.map(c => ({
      name: c.name,
      value: c.value,
      domain: c.domain || '.linkedin.com',
      path: '/',
      httpOnly: true,
      secure: true,
    })));
    
    // Build search URL
    const params = new URLSearchParams({
      keywords,
      f_WT: '2',         // Remote
      f_TPR: 'r604800',  // Last 7 days
      sortBy: 'DD',      // Date Descending
    });
    
    const url = `https://www.linkedin.com/jobs/search/?${params}`;
    
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    
    // Wait for SPA to render job cards
    await page.waitForFunction(() => {
      return document.querySelectorAll('a[href*="/jobs/view/"]').length > 0 ||
             document.querySelector('.jobs-search-no-results') !== null;
    }, { timeout: 30000 }).catch(() => {});
    
    // Check if redirected to login
    if (page.url().includes('/login') || page.url().includes('checkpoint') || page.url().includes('authwall')) {
      console.log('  ❌ LinkedIn: Session expired during scraping.');
      await sendExpirationEmail();
      return [];
    }
    
    // Scrape jobs
    const jobs = await page.evaluate((maxJobs) => {
      const links = document.querySelectorAll('a[href*="/jobs/view/"]');
      const seen = new Set();
      
      return Array.from(links)
        .map(a => {
          // Clean up title (LinkedIn duplicates text)
          let title = a.textContent.trim();
          const half = Math.floor(title.length / 2);
          if (title.length > 4 && title.substring(0, half) === title.substring(half)) {
            title = title.substring(0, half);
          }
          
          return {
            title: title,
            url: a.href.split('?')[0],
          };
        })
        .filter(j => {
          if (!j.title || seen.has(j.url)) return false;
          seen.add(j.url);
          return true;
        })
        .slice(0, maxJobs);
    }, maxJobs);
    
    return jobs;
    
  } catch (err) {
    if (err.message.includes('timeout')) {
      console.log('  ⚠️  LinkedIn: Scraping timeout.');
    } else {
      console.error('  ❌ LinkedIn:', err.message);
    }
    return [];
  } finally {
    await browser.close();
  }
}

// ─── Auto-apply to LinkedIn Easy Apply jobs ──────────────────────────────────

async function applyToJob(url, userId, candidateInfo, cvPath) {
  const data = await loadCookies(userId);
  if (!data || data.cookies.length === 0) {
    return { success: false, error: 'No LinkedIn cookies available' };
  }

  const { valid } = checkCookieAge(data.exportedAt);
  if (!valid) {
    return { success: false, error: 'LinkedIn cookies expired' };
  }

  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: CHROME_PATH,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 800 });

    await page.setCookie(...data.cookies.map(c => ({
      name: c.name,
      value: c.value,
      domain: c.domain || '.linkedin.com',
      path: '/',
      httpOnly: true,
      secure: true,
    })));

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });

    if (page.url().includes('/login') || page.url().includes('authwall')) {
      return { success: false, error: 'LinkedIn session expired — re-login needed' };
    }

    await page.waitForSelector('.jobs-apply-button, button[aria-label*="Apply"]', { timeout: 15000 }).catch(() => {});

    const applyBtn = await page.$('.jobs-apply-button, button[aria-label*="Apply"]');
    if (!applyBtn) {
      return { success: false, error: 'No Apply button found — may require external redirect' };
    }

    await applyBtn.click();
    await page.waitForSelector('.jobs-easy-apply-modal, .artdeco-modal', { timeout: 10000 }).catch(() => {});

    const confirmationPatterns = [/thank you/i, /submitted/i, /application complete/i, /applied/i];
    const nextStepSelectors = [
      'button[aria-label="Continue to next step"]',
      'button[aria-label="Review your application"]',
      'button:has-text("Next")',
      'button:has-text("Continue")',
      'button:has-text("Review")',
    ];
    const submitSelectors = [
      'button[aria-label="Submit application"]',
      'button:has-text("Submit application")',
      'button:has-text("Submit")',
    ];

    for (let step = 0; step < 8; step++) {
      if (candidateInfo.email) {
        await page.evaluate((email) => {
          const inputs = document.querySelectorAll('input[name*="email"], input[type="email"]');
          inputs.forEach(i => { i.value = email; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); });
        }, candidateInfo.email);
      }
      if (candidateInfo.phone) {
        await page.evaluate((phone) => {
          const inputs = document.querySelectorAll('input[name*="phone"], input[type="tel"]');
          inputs.forEach(i => { i.value = phone; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); });
        }, candidateInfo.phone);
      }
      if (candidateInfo.firstName) {
        await page.evaluate((name) => {
          const inputs = document.querySelectorAll('input[name*="first-name"], input[id*="first-name"]');
          inputs.forEach(i => { i.value = name; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); });
        }, candidateInfo.firstName);
      }
      if (candidateInfo.lastName) {
        await page.evaluate((name) => {
          const inputs = document.querySelectorAll('input[name*="last-name"], input[id*="last-name"]');
          inputs.forEach(i => { i.value = name; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); });
        }, candidateInfo.lastName);
      }

      if (cvPath && existsSync(cvPath)) {
        const fileInputs = await page.$$('input[type="file"]');
        for (const fi of fileInputs) {
          const accept = await fi.getAttribute('accept') || '';
          const visible = await fi.evaluate(el => el.offsetParent !== null).catch(() => false);
          if (visible && (accept.includes('pdf') || accept.includes('document') || accept.includes('image'))) {
            try {
              await fi.uploadFile(cvPath);
              await new Promise(r => setTimeout(r, 2000));
            } catch {}
            break;
          }
        }
      }

      const pageText = await page.evaluate(() => document.body?.innerText || '').catch(() => '');
      if (confirmationPatterns.some(p => p.test(pageText))) {
        return { success: true, method: 'LinkedIn Easy Apply (step ' + step + ')' };
      }

      let clicked = false;
      for (const sel of submitSelectors) {
        try {
          const btn = await page.$(sel);
          if (btn && await btn.isVisible().catch(() => false)) {
            await btn.click();
            clicked = true;
            break;
          }
        } catch {}
      }

      if (clicked) {
        await new Promise(r => setTimeout(r, 3000));
        const afterText = await page.evaluate(() => document.body?.innerText || '').catch(() => '');
        if (confirmationPatterns.some(p => p.test(afterText))) {
          return { success: true, method: 'LinkedIn Easy Apply' };
        }
        continue;
      }

      for (const sel of nextStepSelectors) {
        try {
          const btn = await page.$(sel);
          if (btn && await btn.isVisible().catch(() => false)) {
            await btn.click();
            clicked = true;
            break;
          }
        } catch {}
      }

      if (clicked) {
        await new Promise(r => setTimeout(r, 2000));
        continue;
      }

      break;
    }

    return { success: false, error: 'Could not complete LinkedIn application form — may need manual review' };
  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    await browser.close();
  }
}

// ─── Provider interface (default export for registry) ─────────────────────

export default {
  id: 'linkedin',
  name: 'LinkedIn Jobs',
  
  detect(ctx) {
    return false;
  },

  async fetch(entry, ctx) {
    const keywords = entry.scan_query || entry.name || 'AI automation';
    return scrapeLinkedInJobs(keywords, 25, ctx?.userId);
  },

  async apply(url, ctx) {
    return applyToJob(url, ctx?.userId, ctx?.candidateInfo || {}, ctx?.cvPath);
  },
};

// ─── Standalone testing ────────────────────────────────────────────────────

if (process.argv[1]?.endsWith('linkedin.mjs')) {
  console.log('\n🔍 Testing LinkedIn provider (headless)...\n');
  
  const data = loadCookies();
  if (!data) {
    console.log('❌ No config found. Run: node linkedin-auto-save.js');
    process.exit(1);
  }
  
  const { valid, days } = checkCookieAge(data.exportedAt);
  console.log(`Cookie age: ${days} days, Valid: ${valid}`);
  
  if (!valid) {
    console.log('❌ Cookies expired. Run: node linkedin-auto-save.js');
    process.exit(1);
  }
  
  scrapeLinkedInJobs('AI automation', 10).then(jobs => {
    console.log(`\n✅ Found ${jobs.length} jobs:\n`);
    jobs.forEach((job, i) => {
      console.log(`${i + 1}. ${job.title}`);
      console.log(`   ${job.url}\n`);
    });
  }).catch(err => {
    console.error('❌ Error:', err.message);
  });
}
